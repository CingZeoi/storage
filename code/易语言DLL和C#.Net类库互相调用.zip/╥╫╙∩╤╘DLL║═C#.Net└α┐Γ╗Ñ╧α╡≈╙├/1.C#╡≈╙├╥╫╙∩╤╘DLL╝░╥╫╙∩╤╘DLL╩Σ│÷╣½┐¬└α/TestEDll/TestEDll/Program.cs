﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;
using static System.Convert;


namespace TestEDll
{
	class Program
	{
		[DllImport("TestEDll.dll")] extern public static string GetTextFromClipboard();  // 过程函数:取剪贴板文本
		[DllImport("TestEDll.dll")] extern  public static bool SetTextToClipboard(string txt);  // 过程函数:置剪贴板文本
		private static int Main(string[] args)
		{
			Title = "测试调用易语言编译的动态链接库";
			WriteLine("文本复制{0}",(SetTextToClipboard("你好世界！\nHello World!")? "成功" : "失败"));  // 将文本复制到剪贴板
			WriteLine("剪贴板的文本是: {0}",GetTextFromClipboard());  // 显示出剪贴板内的文本
			Rectangle square = new Rectangle() { Length = 3.5, Width = 9.7 };
			WriteLine("矩形 square 的面积是 {0}", square.CalculateArea());
			WriteLine("矩形 square 的周长是 {0}", square.CalculatePerimeter());
			ReadKey(false);
			return (0);
		}
	}

	class Rectangle
	{
		// 公开的类方法第一个参数固定为对象自身的指针值,在调用时使用 this 关键字获得对象自身,后续参数必须与DLL公开类的内部方法中定义的参数顺序及类型完全保持一致。
		[DllImport("TestEDll.dll")] extern static double _rectangle_Length_GetValue(Rectangle ClassSelf);  // 类方法:矩形类私有字段"Length"取值方法
		[DllImport("TestEDll.dll")] extern static void _rectangle_Length_SetValue(Rectangle ClassSelf, double Length);  // 类方法:矩形类私有字段"Length"设值方法
		[DllImport("TestEDll.dll")] extern static double _rectangle_Width_GetValue(Rectangle ClassSelf);  // 类方法:矩形类私有字段"Width"取值方法
		[DllImport("TestEDll.dll")] extern static void _rectangle_Width_SetValue(Rectangle ClassSelf, double Width);  // 类方法:矩形类私有字段"Width"设值方法
		[DllImport("TestEDll.dll")] extern static double _rectangle_CalculateArea(Rectangle ClassSelf);  // 类方法:矩形类计算面积
		[DllImport("TestEDll.dll")] extern static double _rectangle_CalculatePerimeter(Rectangle ClassSelf);  // 类方法:矩形类计算周长
		public double Length
		{
			get
			{
				return (_rectangle_Length_GetValue(this));
			}
			set
			{
				_rectangle_Length_SetValue(this,value);
			}
		}
		public double Width
		{
			get
			{
				return (_rectangle_Width_GetValue(this));
			}
			set
			{
				_rectangle_Width_SetValue(this, value);
			}
		}
		public double CalculateArea ()
		{
			return (_rectangle_CalculateArea(this));
		}
		public double CalculatePerimeter ()
		{
			return(_rectangle_CalculatePerimeter(this));
		}
	}
}
