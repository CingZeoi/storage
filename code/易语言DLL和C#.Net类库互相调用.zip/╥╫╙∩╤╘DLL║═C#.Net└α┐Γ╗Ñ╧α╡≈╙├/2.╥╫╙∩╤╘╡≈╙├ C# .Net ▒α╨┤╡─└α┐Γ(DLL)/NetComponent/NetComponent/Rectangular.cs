﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;


namespace NetComponent
{
	public interface iRectangular
	{
		double Length { get; set; }
		double Width { get; set; }
		double GetPerimeter();
		double GetArea();
	}

	[ClassInterface(ClassInterfaceType.None)]
	public class Rectangular : iRectangular
	{
		public double Length
		{
			get
			{
				return (this.LengthX);
			}
			set
			{
				this.LengthX = (value > 0 ? value : 1);
			}
		}
		public double Width
		{
			get
			{
				return (this.WidthX);
			}
			set
			{
				this.WidthX = (value > 0 ? value : 1);
			}
		}
		private double LengthX;
		private double WidthX;
		public double GetPerimeter()
		{
			return ((this.LengthX + this.WidthX) * 2);
		}
		public double GetArea()
		{
			return (this.LengthX*this.WidthX);
		}
	}
}
