易语言调用C#编写的.net类库

办法是:将C#编写的类库注册为Com组件，然后使用易语言调用。
VS新建一个C# .net类库工程。修改项目属性:
1.勾选 生成>为 COM 互操作注册 复选框
2.勾选 应用程序>程序级信息>使程序集 COM 可见 复选框
编写类库代码并生成DLL
由于这是.net类库，必须注册com组件后才可被易语言调用，要用到"regasm.exe"工具来注册。
regasm.exe通常在 ""C:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe"
注册方法:打开CMD输入"C:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe" /c "DLL所在路径"
例如: "C:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe" /c "d:\testcom\edemo\mycom.dll"
卸载注册的组件:只需把参数"/c"改为 "/u" 即可，例如:"C:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe" /u "d:\testcom\edemo\mycom.dll"
注册成功后即可在易语言中采用对象的方式来调用
